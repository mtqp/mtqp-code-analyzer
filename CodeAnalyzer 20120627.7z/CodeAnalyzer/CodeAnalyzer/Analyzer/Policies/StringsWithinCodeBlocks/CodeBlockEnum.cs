﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeAnalyzer.Enums
{
    public enum CodeBlockEnum
    {
        Class,
        Methods,
        Property,
        Variable,
        Cicle
    }
}
