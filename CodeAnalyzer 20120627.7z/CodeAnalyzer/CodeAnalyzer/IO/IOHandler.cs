﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CodeAnalyzer.Enums;
using System.IO;
using CodeAnalyzer.Analyzer;

namespace CodeAnalyzer.IO
{
    public class IOHandler
    {
        public static CodeFile TryOpen(string path, FileMode mode, out IOOperationResultEnum result)
        {
            StreamReader fileStream = null;
            CodeFile codeFile = null;

            if (File.Exists(path))
            {
                fileStream = new StreamReader(path); //FileStream(path, mode);
                codeFile = new CodeFile(fileStream);
                result = IOOperationResultEnum.Success;
            }
            else
                result = IOOperationResultEnum.Error;

            return codeFile;
        }

    }
}
